
The source code in the package "magicbeans" is part of Learning Java, 
3rd editon.  The source code in the package "learningjava.sunw.*" 
(specifically for "juggler" and "molecule") is derived from Sun's BDK Java 
Beans examples.  See BDK-License.txt for the Sun's license.

Due to copyright concerns we did not distribute the images of the juggling 
Java "Duke" character with the Juggler JavaBean example.  We have substituted 
our own replacements.

If you want the original images you can find them in the download of Sun's 
BDK application here:

  http://java.sun.com/products/javabeans/software/bdk_download.html


