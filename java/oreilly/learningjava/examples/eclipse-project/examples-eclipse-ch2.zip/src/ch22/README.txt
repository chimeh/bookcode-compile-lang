
magicbeans.jar - the pre-compiled and packaged JavaBeans examples

  The 'magicbeans' dirctory contains an Ant build file and source for creating 
  the magicbeans.jar file.

Running the BackFromTheDead Example:

   # Windows
   java -classpath magicbeans.jar;. BackFromTheDead Juggler_juggler1

   # Unix
   java -classpath magicbeans.jar:. BackFromTheDead Juggler_juggler1


