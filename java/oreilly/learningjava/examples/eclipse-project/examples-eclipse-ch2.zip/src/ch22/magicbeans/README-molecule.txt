
NetBeans 3.x Java 1.4.x -

There is a bug in the interaction between the molecule example and NetBeans
3.3.1.  Choosing a molecule type other than the default in the property editor
does not produce compilable code.

Please check the web site for updates:

  http://www.ora.com/catalog/learnjava2/


