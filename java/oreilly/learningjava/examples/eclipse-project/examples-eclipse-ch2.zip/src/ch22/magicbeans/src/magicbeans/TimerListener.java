package magicbeans;

public interface TimerListener extends java.util.EventListener {
	void timerFired( TimerEvent e );
}
